/**
 * 提供数据组件，如 表格 datagrid， 表单 dataform，树 tree 等。 数据组件用来加载列表，表单，和树的数据显示。
 */