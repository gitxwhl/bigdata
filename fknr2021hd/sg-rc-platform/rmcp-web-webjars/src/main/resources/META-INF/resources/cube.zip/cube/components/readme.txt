The cube_framework try to give developers ui components.

Here we try to implement components with bootstrap frame. 

We tried to implement components with other frameworks, such as jqx, however this way is not as what we wished to do.

dropdownlist/navbar/tabcontainer components is used bootstrap
calendar component tries to use css3 ui

These components just demos, in fact, we will rewrite the components, and to use 'cube_' before every component name.
